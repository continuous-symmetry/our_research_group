This file contains the run command for: Example 2 - A crystal with pseudo-symmetry.

Calculate the CSM for the molecule CILHAI.sdf with respect to the Ci point group:
$ csm exact ci --input CILHAI.sdf --output out_cilhai --keep-structure

After running the command, the results will be in the directory out_cilhai,  and the CSM will also be printed to the screen.
