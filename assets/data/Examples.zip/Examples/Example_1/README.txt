This directory contains the molecules and the results for:
Example 1 - Flexible cage molecules.

There are three example runs:

1. Calculate the CSM for the molecule AWEWOR.sdf with respect to the C3 point group:
$ csm exact c3 --input AWEWOR.sdf --output out_awewor --keep-structure

2. Calculate the CSM for all the files in the directory with the respect to the C3 point group:
$csm exact c3 --input . --output out_all --keep-structure

3. Calculate the CSM for all the files in the directory with two symmetry point groups, defined in the file cmd.txt:
$ csm comfile cmd.txt --input . --output out_c2_c3 

After running the above commands, the results will be in the respective directories: out_awewor, out_all and out_c2_c3.
