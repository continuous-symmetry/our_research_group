This directory contains the input and output files for: 
Example 3 - Conformational change of SARS-CoV-2 spike protein

There are three runs:
1. Calculate the CSM for all the files in the directory with respect to the C3 point group:
$ csm approx c3 --input . --output out_sars_c3 --use-chains --use-sequence --babel-bond

2.  Calculate the CSM for  all the files in the directory with respect to the C3 point group, using the backbone atoms:
$ csm approx c3 --input . --output out_backbone --use-chains --use-sequence --babel-bond --use-backbone

3.  Calculate the CSM for the RBD domains of all the files in the directory with respect to the C3 point group:
$ csm approx c3 --input . --output out_rbd --use-chains --use-sequence --select-res 330-527 --babel-bond

After running the above commands, the results will be in the respective directories: out_sars_c3, out_backbone and out_rbd. 
